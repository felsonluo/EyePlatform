
export interface Audio {
    Id?: number;
    Url: string;
    Title?: string;
    Size?: number;
    DuringSecond?: string;
    Cover?: string;
}
