export class BaseModel {

    EId?: string;

    EName?: string;

    EIsActive?: boolean;
}