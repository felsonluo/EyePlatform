import { BaseModel } from "./base.model";

//币种
export class CurrencyModel extends BaseModel {

    //符号
    ESymbol?: string;
}