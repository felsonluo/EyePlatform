import { BaseModel } from "./base.model";

export class DocumentModel  extends BaseModel{

    EPath?: string;

    EIsMaster?: boolean;
}