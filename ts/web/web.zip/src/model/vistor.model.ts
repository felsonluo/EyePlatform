import { BaseModel } from "./base.model";

//客户
export class Visitor extends BaseModel {

    EEmail?: string;

    ETelephone?: string;

    EWechatId?: string;

    EQQ?: string;

    EIP?: string;
}