//键值对
export class KeyValuePairs {

    key?: string;

    value?: any;
}